insert into Example_Domain
values(10001,'Ranga', 'E1234567');

insert into Example_Domain
values(10002,'Ravi', 'A1234568');